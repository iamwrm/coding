clear
a=imread('Capture001.png');
a1=rgb2ind(a);