#pragma once

void increase(int *& b);
