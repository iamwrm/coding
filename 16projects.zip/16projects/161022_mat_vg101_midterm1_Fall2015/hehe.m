clear
a=cell(1,5)
a{1:2}={'asdf' };
fprintf(a{1})