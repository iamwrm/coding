#include<stdio.h>


int main(){


    unsigned char i=1,y;
    y=~i;
    printf("%d\n",y);
    getchar();


}