[n,PI] = myPi();
a=[n,PI]