#include <iostream>
#incldue <fstream>


int main(){







return 0;
}
