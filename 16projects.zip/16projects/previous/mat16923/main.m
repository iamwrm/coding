clear all;
clc
a=[1:5e5];
b=char(a);

ii=1;

while ii<=500000
    if b(1,ii)=='Íõ'
    b(1,ii)
    end
    ii=ii+1
end


%呵呵呵
    