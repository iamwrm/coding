王韧 Ren Wang
Stu.ID:516370910177
2016-09-28

<font size=10>

### Exercise 1.1  
|Greek|Engish name|
|-----|----------:|
|$\alpha$|
|$\beta$|
|$\gamma$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|
|$\$|


</font>
