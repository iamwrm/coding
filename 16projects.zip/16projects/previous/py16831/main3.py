#试试看怎么让print不换行

i=1;
while i<5:
    i=i+1
    print('heh',end='')   #成功了，加一个end="" 或者''两者无区别