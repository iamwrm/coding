#实验while循环
i=0
while i<=99:
    if (i%2)==1:
        print(i+1)
    i=i+1
    
    