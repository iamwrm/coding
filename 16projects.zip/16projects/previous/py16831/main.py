#这个程序是用来实验python中循环的

names=['a','b','c']
for a in names:         # for...in 循环
    print (a)
