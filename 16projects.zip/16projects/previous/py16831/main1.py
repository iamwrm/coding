#使用range

a=range(0,101)
sum=0
for f in a:
    sum=sum+f
    print(f)
print('\\')
print(sum)

