
print("Hello, World!你好");
a=10
b=1000


a=a+b
print (a)
