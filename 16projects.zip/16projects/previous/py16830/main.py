#格式化输出
#%d	integer  %f	  float  %s string  %x	hex
a='c'
b='d'
print('a+b=%s'%(a))
print(hex(10))
f=ord('王')
print(f)

print('goodlord')