This is [an example](http://example.com/ ) inline link.

[This link](http://example.net/) has no title attribute.



[id]: http://example.com/  "Optional Title Here"
This is [an example][id] reference-style link.
