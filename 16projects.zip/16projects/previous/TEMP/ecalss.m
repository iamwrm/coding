clear
clc
for i1=1:100
 	a1=['a',num2str(2*i1)];
     eval(['mat_out',num2str(i1),'=a1']);
 end
