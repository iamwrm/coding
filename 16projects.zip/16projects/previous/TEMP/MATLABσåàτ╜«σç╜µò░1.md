`iskeyword` 查看是否为 保留字

`edit functionname` 看MATLAB源码（并不好用）

`@` 匿名函数

`repmat` 通过重复，生成更大的矩阵

`bench` 电脑跑分

`fliplr`  矩阵次序颠倒 也可以写`b=a(end:-1:1)`

去除`NaN` 用`a(isnan(a))=[]`




`eval(' ')` 将字符串转化为MATLAB语句
可以用来批量创建变量a1,a2..a100

数学函数
-----
`factor` 求一个数的质数因子
`isprime`
`primes`
`gcd`
`lcm`
`rat`
`rats`
`nchoosek`

复数
----

`abs`
`imag`
`real`
`isreal`

取整求余
---
