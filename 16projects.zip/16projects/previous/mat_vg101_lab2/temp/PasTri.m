function PasTri( n_of_tri )
%
%



n_of_tri=3; %

mat_out=[];
mat_out(1,:)='      1      ';
mat_out(2,:)='   1     1   ';







end

