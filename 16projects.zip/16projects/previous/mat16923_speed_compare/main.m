clear all;
clc;
time1=clock;
a1=ran(1,1000)



etime