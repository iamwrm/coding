#字典与不可变对象
list1=[1,2,3,4]
tuple1=(11,12,13,14)
dict1={1:21,tuple1:22}
print(dict1[tuple1])
