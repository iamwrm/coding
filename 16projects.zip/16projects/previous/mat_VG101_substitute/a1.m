input_string=['1 and 2 and 3 and 12 are one and two and three'];
 input_string=strrep(input_string,'1','one');
input_string=strrep(input_string,'2','two');
input_string=strrep(input_string,'3','three');
input_string
