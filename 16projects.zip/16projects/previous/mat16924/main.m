T=1;
Y=1:4;
yprime(T,Y)