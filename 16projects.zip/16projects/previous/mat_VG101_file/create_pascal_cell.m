clc
mat_out=cell(5);
mat_out{2,2}=123456;
disp(mat_out);
mat_out{2,3}=cell(3)
disp(mat_out);