clc
clear
load store