clc
clear
point1=[0;0];
point2=[2;0];
point3=[1;sqrt(3)];
hold on;
my_tri(point1,point2,point3,1,8)