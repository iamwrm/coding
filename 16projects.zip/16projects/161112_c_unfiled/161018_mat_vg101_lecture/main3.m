clc
global cal
cal=0
main2