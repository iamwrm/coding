#include <stdio.h>
int main(int argc, char const *argv[]) {
  char a[4]="hehe";
  /*

  */
  printf("%s\n",a );
  return 0;
}
