// 

#include <stdio.h>
int main(int argc, char const *argv[]) {
  char* a;
  a="hehe";
  printf("%s\n",a );
  return 0;
}
