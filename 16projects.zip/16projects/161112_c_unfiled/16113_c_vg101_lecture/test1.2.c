#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"

int main(int argc, char const *argv[]) {
    char input[100];
    scanf("%s",input );
    char* ip;
    ip=input;

    while (*ip != '\0') switch (*ip) {
        case /* value */:
    }

    printf("%c",*ip++ );



    return 0;
}
