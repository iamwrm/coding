c = 'zeros';
fh = str2func(c)

fh(1,5)