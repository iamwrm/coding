clear
clc
a0=[0;0];
a3=[3;0];

sixangle(a0,a3,1,4)
