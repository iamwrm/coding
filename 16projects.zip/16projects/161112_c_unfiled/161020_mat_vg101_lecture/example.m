for i1=1:20
a(i1)=i1+unidrnd(2)
end

[fitresult, gof] = createFit1(a)

