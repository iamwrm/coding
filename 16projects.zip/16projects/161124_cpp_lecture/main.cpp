#include<iostream>


int main() {

	using namespace std;
	cout << "heheheh" << endl;
	getchar();
	getchar();
	getchar();

}