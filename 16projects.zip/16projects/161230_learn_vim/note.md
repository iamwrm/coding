# 软件匠艺小组 vim 教程note 

## basic keymap

ctrl + [      (the same as esc)


### up down left right

j k l h



### jump

``gg`` go to head

``G`` go to end

``*gg`` go to the  ``*th`` line

``f + * `` go to the first word which begins with the letter ``*`` in this line 

### copy and paste or edit

``yy`` to copy a line (only a line) then use ``p`` to paste

``dd`` delete a line

`` d i w `` to delete a word (nomatter where the crusior is in the word)








